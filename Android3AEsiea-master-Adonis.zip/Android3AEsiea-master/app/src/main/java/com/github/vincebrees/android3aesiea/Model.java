package com.github.vincebrees.android3aesiea;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import java.text.DecimalFormat;

public class Model {

    // Format utilisé pour afficher les données temporelles
    DecimalFormat df = new DecimalFormat("0.00");

    // Nombre de hash calculé par million en fonction de la taille 8 -> 15 (approximatif)
    double[] hashRateMillionBySecond = {41825, 4182, 418, 41, 4, 0.4, 0.04, 0.004};

    // Calcule le temps nécessaire approximatif pour casser un password
    public double computeComplexity(String inputUser)
    {
        int daysComputed = 0;
        // Découpe la string par car et la stock dans un tableau
        char[] inputInArray = inputUser.toCharArray();

        // Calcul le nombre de permutation possible (donc le nombre max de hash généré)
        long nbPermutation = countPermutation(inputInArray);

        // En fcontion de la longueur, effectue une opération simple avec la bonne valeur du tableau "hashRateMillionBySecond"
        if (inputInArray.length >= 1 && inputInArray.length <= 8) return nbPermutation/hashRateMillionBySecond[0];
        else if (inputInArray.length == 9) return nbPermutation/hashRateMillionBySecond[1];
        else if (inputInArray.length == 10) return Math.round(nbPermutation/hashRateMillionBySecond[2]);
        else if (inputInArray.length == 11) return Math.round(nbPermutation/hashRateMillionBySecond[3]);
        else if (inputInArray.length == 12) return Math.round(nbPermutation/hashRateMillionBySecond[4]);
        else if (inputInArray.length == 13) return Math.round(nbPermutation/hashRateMillionBySecond[5]);
        else if (inputInArray.length == 14) return Math.round(nbPermutation/hashRateMillionBySecond[6]);
        else if (inputInArray.length == 15) return Math.round(nbPermutation/hashRateMillionBySecond[7]);
        else return -1;

        /*for (int i=0; i < inputInArray.length; i++)
        {
            if (Character.isDigit(inputInArray[i])) daysComputed += 1;
            else if (Character.isAlphabetic(inputInArray[i])) daysComputed += 1;
            else if (isSpecial(inputInArray[i])) daysComputed += 2;
            else return -1;

        }*/
//        return daysComputed;
    }

    // Opération factiorel simple pour compter le nombre de permutation possible
    private long countPermutation(char[] inputInArray) {
        long result = 1;

        for (int factor = 2; factor <= inputInArray.length; factor++) {
            result *= factor;
        }

        return result;
    }

    // Création d'une string facilement lisible pour un humain depuis un temps en seconde
    public StringBuffer humanFormatOutput(double secondes){
        StringBuffer buff = new StringBuffer("");

        // Récupère la longueur du nombre et applique la bonne unité
        int sizeSec = df.format(secondes).length();

        if (sizeSec == 3 || sizeSec == 4 || sizeSec == 5)
        {
            buff.append(df.format(secondes));
            buff.append(" secondes.");
        }
        else if (sizeSec == 6 || sizeSec == 7){
            buff.append(df.format(secondes / 3600.0));
            buff.append(" heuress.");
        }
        else if (sizeSec == 8 || sizeSec == 9){
            buff.append(df.format(secondes / (3600.0*24)));
            buff.append(" jours.");
        }
        else {
            buff.append(df.format(secondes / (3600.0*24*365)));
            buff.append(" années.");
        }

        return buff;
    }

    // Vérifie si un charactère est considéré comme spécial. Fonction non utlisé à ce jour.
    private boolean isSpecial(char c) {
        String specialCharString = " !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~";
        if (specialCharString.indexOf(c) != -1) return true;
        else return false;
    }
}
