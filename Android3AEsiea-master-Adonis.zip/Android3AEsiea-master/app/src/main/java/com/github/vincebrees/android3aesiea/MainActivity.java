package com.github.vincebrees.android3aesiea;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

// Cette classe sert de controlleur dans un paradigme MVC.

public class MainActivity extends AppCompatActivity {



    // Initialisation de la vue et du model
    Vue vue = new Vue();
    Model model = new Model();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialisation et affectation des éléments de la vue
        vue.setmButton((Button)findViewById(R.id.button));
        vue.setmEdit((EditText)findViewById(R.id.editText));
        vue.setmTextView((TextView)findViewById(R.id.textView3));
        vue.setTextView((TextView) findViewById(R.id.textView4));

        // Usage de 2 variables fixe pour l'appel api
        final RequestQueue queue = Volley.newRequestQueue(this);
        final String url ="https://api.pwnedpasswords.com/range/";

        // Ajout d'un listener sur le bouton de la vue
        vue.getmButton().setOnClickListener(
                new View.OnClickListener()
                {
                    public void onClick(View view)
                    {
                        // Récupération de l'input utilisateur
                        String inputUser = vue.getmEdit().getText().toString();

                        // Calcul du temps approximatif en seconde nécessaire pour casser l'input
                        double secondes = model.computeComplexity(inputUser);

                        // Format la variable en données lisibles plus facilemen (seconde, heures, jours, etc)
                        StringBuffer days = model.humanFormatOutput(secondes);

                        // Hash au format NTLM le password pour envoie vers HIBP
                        String hashInputUser = NTLMPassword.encode(inputUser);

                        // Appel API vers HIBP
                        getHIBP(queue, url, hashInputUser);

                        // Affichage du temps nécessaire approximatif pour casser l'input
                        vue.getmTextView().setText("Votre mot de passe est cassable en : " + days);
                    }
                });

    }

    // Fonction appel API
    private void getHIBP(RequestQueue queue, String url, final String hashInputUser) {
        // Récupère les 5 premier car du hash (nécessaire pour le préfix dans l'appel API)
        url += hashInputUser.substring(0,5);
        final String finalUrl = url;

        // Création d'une requête
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                // Ajout d'un listener
                new Response.Listener<String>() {
                    // Attends la réponse
                    @Override
                    public void onResponse(String response) {
                        // Découpe la réponse réçu dans un tableau
                        String[] hashHIBP = response.split("\\r?\\n");
                        // Parcours chaque élément du tableau et le compare avec le hash d'input
                        for (String hash : hashHIBP) {
                            if (hash.equals(hashInputUser)){
                                // Affiche un message informatif sur l'état du password
                                vue.getTextView().setText("Votre mot de passe a fuité");
                               break;
                            }
                        }
                        // Affiche un message informatif sur l'état du password
                        vue.getTextView().setText("Votre mot de passe n'a pas fuité.");

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                // Affiche un message informatif sur l'état du password
                vue.getTextView().setText("HIBP LINK ERROR : " + finalUrl);
            }
        });

        queue.add(stringRequest);
    }



}
