package com.github.vincebrees.android3aesiea;

import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

public class Vue {

    // Initialisation des 4 éléments de la vue principale

    private Button mButton;
    private EditText mEdit;
    private TextView mTextView;
    private TextView textView;

    // Création des getter & Setters

    public Button getmButton() {
        return mButton;
    }

    public EditText getmEdit() {
        return mEdit;
    }

    public TextView getmTextView() {
        return mTextView;
    }

    public TextView getTextView() {
        return textView;
    }

    public void setmButton(Button mButton) {
        this.mButton = mButton;
    }

    public void setmEdit(EditText mEdit) {
        this.mEdit = mEdit;
    }

    public void setmTextView(TextView mTextView) {
        this.mTextView = mTextView;
    }

    public void setTextView(TextView textView) {
        this.textView = textView;
    }
}
